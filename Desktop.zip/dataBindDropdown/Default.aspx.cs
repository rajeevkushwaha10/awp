﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("Data Source=COMPLAB\\SQLEXPRESS;Initial Catalog=tyit;Integrated Security=true"); 
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from EmpDetails where EmpID = '" + DropDownList1.SelectedValue + "'", conn);
        SqlDataAdapter dap = new SqlDataAdapter(cmd);
        DataSet dt = new DataSet(); 
        dap.Fill(dt);
        GridView1.DataSource = dt; 
        GridView1.DataBind();
        Label1.Text = "record found"; 
    }
}