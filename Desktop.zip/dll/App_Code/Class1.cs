﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
	
        public int add(int a,int b)         
        {             
            int sum = a + b;             
            return sum;         
        } 
        public int subtract(int a, int b)        
        {             
            int sub = a - b;             
            return sub;          
	    }
}