﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Default5 : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("Data Source = COMPLAB\\SQLEXPRESS; Initial Catalog = tyit; Integrated Security = true");

    protected void Button1_Click(object sender, EventArgs e)
    {
        conn.Open();
        string cmdText1 = "insert into EmpDetails values(@empid,@name,@city,@state)";
        SqlCommand cmd1 = new SqlCommand(cmdText1, conn);
        cmd1.Parameters.AddWithValue("@empid", TextBox1.Text);
        cmd1.Parameters.AddWithValue("@name", TextBox2.Text);
        cmd1.Parameters.AddWithValue("@city", TextBox3.Text);
        cmd1.Parameters.AddWithValue("@state", TextBox4.Text);
        cmd1.ExecuteNonQuery(); conn.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select * from EmpDetails", conn);
        SqlDataAdapter dap = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        dap.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        conn.Open();
        string cmdText2 = "delete from EmpDetails where EmpID=@empid";
        SqlCommand cmd2 = new SqlCommand(cmdText2, conn);
        cmd2.Parameters.AddWithValue("@empid", TextBox1.Text);
        cmd2.ExecuteNonQuery();
        conn.Close();
    }
}