﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstname;
                 string lastname;
                 firstname = "Steven Clark";
                 lastname = "Clark";
                 Console.WriteLine(firstname.Clone());
                 Console.WriteLine(String.Concat(firstname,lastname)); 
                Console.WriteLine(firstname.CompareTo(lastname)); 
                Console.WriteLine(firstname.Contains("ven"));
                 Console.WriteLine(firstname.EndsWith("n"));
                 Console.WriteLine(firstname.Equals(lastname)); 
                Console.WriteLine(firstname.GetType());
                 Console.WriteLine(firstname.IndexOf("e"));
                 Console.WriteLine(firstname.ToLower());
                 Console.WriteLine(firstname.ToUpper());
                 Console.WriteLine(firstname.Insert(0, "Hello"));
                 Console.WriteLine(firstname.LastIndexOf("e"));


                Console.WriteLine(firstname.Length);
                Console.WriteLine(firstname.Remove(5)); 
                Console.WriteLine(firstname.Replace('e', 'i'));
                string[] split = firstname.Split(' ');
                Console.WriteLine(split[0]); 
                Console.WriteLine(split[1]); 
                Console.WriteLine(firstname.StartsWith("S"));
                Console.WriteLine(firstname.Substring(2, 3)); 
                Console.WriteLine(firstname.ToCharArray());
                Console.WriteLine(firstname.Trim());
                Console.ReadKey();
        }
    }
}
