﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, revnum = 0, digit, sumDigits = 0;
            Console.Write("Enter number:");
            num = int.Parse(Console.ReadLine());
            while (num > 0)
            {
                digit = num % 10;
                sumDigits = sumDigits + digit;
                revnum = revnum * 10 + digit;
                num = num / 10;
            }
            Console.WriteLine("Reverse is" + revnum);
            Console.WriteLine("Sum of its digits:" + sumDigits);
            Console.ReadLine();
        }
    }
}
