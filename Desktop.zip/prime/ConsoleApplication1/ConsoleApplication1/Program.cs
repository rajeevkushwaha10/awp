﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i, flag = 0;
            Console.WriteLine("Enter a positive number");
            n = int.Parse(Console.ReadLine());
            for (i = 2;
            i <= n - 1; ++i)
            {
                if (n % i == 0)
                {
                    flag = 1;
                    Console.WriteLine("This is not a prime number");
                    break;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("This is a prime number");
            }
            Console.ReadLine();
        }
    }
}
