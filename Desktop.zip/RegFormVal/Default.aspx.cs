﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (IsValid)
        {
            string filename = FileUpload1.FileName; FileUpload1.SaveAs(Server.MapPath("~/Images/" + filename));

            Label1.Text = TextBox1.Text + " " + TextBox2.Text + "  " + TextBox3.Text + "<br/>" + TextBox4.Text + "<br/>" + TextBox5.Text + "<br/>" + TextBox6.Text + "<br/>" + TextBox7.Text + "<br/>" + TextBox8.Text + "<br/>" + TextBox9.Text;

        } 
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        TextBox1.Text = ""; 
        TextBox2.Text = ""; 
        TextBox3.Text = ""; 
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox7.Text = "";
        TextBox8.Text = ""; 
        TextBox9.Text = ""; 
    }
}