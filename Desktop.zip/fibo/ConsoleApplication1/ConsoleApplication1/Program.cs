﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, temp;
            num1 = 0;
            num2 = 1;
            Console.WriteLine(num1);
            while (num2 < 100)
            {
                Console.WriteLine(num2);
                temp = num1 + num2;
                num1 = num2;
                num2 = temp;
            }
            Console.ReadLine();
        }
    }
}
